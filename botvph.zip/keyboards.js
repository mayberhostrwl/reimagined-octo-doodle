const { Markup } = require('telegraf');

function createStartKeyboard() {
    return Markup.inlineKeyboard([
        [Markup.button.callback('⚡ Топовые тарифы', 'get_vpn')],
        [Markup.button.callback('💎 Премиум профиль', 'profile'), Markup.button.callback('💳 Баланс', 'balance')],
        [Markup.button.callback('� Зеркала', 'mirrors')],
        [Markup.button.callback('🛡 Консьерж 24/7', 'support')]
    ]);
}

function createPlanKeyboard() {
    return Markup.inlineKeyboard([
        [Markup.button.callback('⚡ 1 месяц • 300 ⭐', 'plan_1m')],
        [Markup.button.callback('🔥 3 месяца • 800 ⭐', 'plan_3m')],
        [Markup.button.callback('💎 6 месяцев • 1500 ⭐', 'plan_6m')],
        [Markup.button.callback('⬅️ Главное меню', 'back_to_start')]
    ]);
}

function createProfileKeyboard() {
    return Markup.inlineKeyboard([
        [Markup.button.callback('💠 Мои подключения', 'my_subscriptions')],
        [Markup.button.callback('🔄 Продлить доступ', 'get_vpn'), Markup.button.callback('💰 Баланс', 'balance')],
        [Markup.button.callback('🌐 Зеркала', 'mirrors')],
        [Markup.button.callback('⬅️ Назад', 'back_to_start')]
    ]);
}

function createSupportKeyboard() {
    return Markup.inlineKeyboard([
        [Markup.button.callback('💬 Связаться с консьержем', 'support')],
        [Markup.button.callback('⬅️ Главное меню', 'back_to_start')]
    ]);
}

function createPaymentKeyboard() {
    return Markup.inlineKeyboard([
        [Markup.button.callback('💳 Пополнить баланс', 'balance')],
        [Markup.button.callback('⬅️ К тарифам', 'get_vpn')]
    ]);
}

function createMirrorsKeyboard(mirrors = []) {
    const rows = mirrors.map((mirror) => [Markup.button.url(mirror.title || mirror.url, mirror.url)]);
    rows.push([Markup.button.callback('⬅️ Главное меню', 'back_to_start')]);
    return Markup.inlineKeyboard(rows);
}

module.exports = {
    createStartKeyboard,
    createPlanKeyboard,
    createProfileKeyboard,
    createSupportKeyboard,
    createPaymentKeyboard,
    createMirrorsKeyboard
};