const axios = require('axios');
const { v4: uuidv4 } = require('uuid');

class MarzbanClient {
    constructor() {
        this.baseUrl = (process.env.MARZBAN_API_URL || '').replace(/\/$/, '');
        this.username = process.env.MARZBAN_ADMIN_USER || process.env.MARZBAN_USER || '';
        this.password = process.env.MARZBAN_ADMIN_PASS || process.env.MARZBAN_PASSWORD || '';
        this.timeout = Number(process.env.MARZBAN_TIMEOUT || 10000);
        this.vlessFlow = process.env.MARZBAN_VLESS_FLOW || 'xtls-rprx-vision';
        this.vlessInbounds = (process.env.MARZBAN_VLESS_INBOUNDS || 'VLESS TCP REALITY')
            .split(',')
            .map((item) => item.trim())
            .filter(Boolean);
        this.userPrefix = process.env.MARZBAN_USER_PREFIX || 'hackvpn';
        this.dataLimit = Number(process.env.MARZBAN_DATA_LIMIT || 0);
        this.dataLimitReset = process.env.MARZBAN_DATA_RESET || 'no_reset';
        this.token = null;
        this.tokenExpiresAt = 0;
    }

    isConfigured() {
        return Boolean(this.baseUrl && this.username && this.password);
    }

    async authenticate() {
        if (!this.isConfigured()) {
            throw new Error('Marzban API is not configured');
        }

        const url = `${this.baseUrl}/api/admin/token`;
        const { data } = await axios.post(
            url,
            {
                username: this.username,
                password: this.password
            },
            { timeout: this.timeout }
        );

        this.token = data.access_token;
        const expiresInMs = (data.expires_in || 3600) * 1000;
        this.tokenExpiresAt = Date.now() + expiresInMs - 5000;
    }

    async ensureToken() {
        if (!this.token || Date.now() >= this.tokenExpiresAt) {
            await this.authenticate();
        }
    }

    async request(config) {
        await this.ensureToken();

        const response = await axios.request({
            baseURL: this.baseUrl,
            timeout: this.timeout,
            headers: {
                Authorization: `Bearer ${this.token}`,
                'Content-Type': 'application/json',
                ...(config.headers || {})
            },
            ...config
        });

        return response;
    }

    async getUser(username) {
        if (!this.isConfigured()) return null;

        try {
            const { data } = await this.request({
                method: 'get',
                url: `/api/user/${username}`
            });
            return data;
        } catch (error) {
            if (error.response?.status === 404) {
                return null;
            }
            throw error;
        }
    }

    calculateExpire(currentExpire, durationMs) {
        const now = Date.now();
        const base = currentExpire && currentExpire > now ? currentExpire : now;
        return base + durationMs;
    }

    buildPayload({ username, expire, planCode }) {
        return {
            username,
            proxies: {
                vless: {
                    flow: this.vlessFlow
                }
            },
            inbounds: {
                vless: this.vlessInbounds
            },
            expire,
            status: 'active',
            data_limit: this.dataLimit,
            data_limit_reset_strategy: this.dataLimitReset,
            note: `plan:${planCode}|order:${uuidv4()}`
        };
    }

    async provisionUser({ userId, durationDays, planCode }) {
        if (!this.isConfigured()) {
            throw new Error('Marzban API credentials are missing');
        }

        if (!durationDays) {
            throw new Error('Duration is required to provision a user');
        }

        const durationMs = durationDays * 24 * 60 * 60 * 1000;
        const username = `${this.userPrefix}_${userId}`;
        const existing = await this.getUser(username);
        const expire = this.calculateExpire(existing?.expire, durationMs);
        const payload = this.buildPayload({ username, expire, planCode });

        const requestConfig = existing
            ? { method: 'put', url: `/api/user/${username}`, data: payload }
            : { method: 'post', url: '/api/user', data: payload };

        const { data } = await this.request(requestConfig);

        return {
            username: data.username,
            expire: data.expire,
            subscription_url: data.subscription_url,
            links: data.links || {}
        };
    }
}

module.exports = new MarzbanClient();
