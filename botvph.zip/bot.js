require('dotenv').config();

const { Telegraf, Markup } = require('telegraf');
const Database = require('./database');
const fs = require('fs');
const fsp = require('fs/promises');
const marzbanClient = require('./marzbanClient');
const {
    createStartKeyboard,
    createPlanKeyboard,
    createProfileKeyboard,
    createSupportKeyboard,
    createPaymentKeyboard,
    createMirrorsKeyboard
} = require('./keyboards');

const BOT_TOKEN = '8447465438:AAE1etW2JkSt4waoSDxZ0Nyibliyz9b3-3s';
const ADMINS = [7672279647, 7833861550];
const TG_CHANNEL = 'https://t.me/+tNJeA0z3G51mMjgy';
const RATE_LIMIT_WINDOW_MS = 60000;
const RATE_LIMIT_MAX_REQUESTS = 5;

const PLANS = {
    plan_1m: { code: 'plan_1m', label: '1 месяц', price: 300, durationDays: 30, emoji: '⚡' },
    plan_3m: { code: 'plan_3m', label: '3 месяца', price: 800, durationDays: 90, emoji: '🔥' },
    plan_6m: { code: 'plan_6m', label: '6 месяцев', price: 1500, durationDays: 180, emoji: '💎' }
};

function formatPlanHighlights() {
    return Object.values(PLANS)
        .map(plan => `${plan.emoji} <b>${plan.label}</b> — ${plan.price} ⭐ / ${plan.durationDays} дней`)
        .join('\n');
}

function formatExpireDate(timestamp) {
    if (!timestamp) return 'не указано';
    return new Date(timestamp).toLocaleString();
}

function formatMirrorsText(mirrors) {
    if (!mirrors.length) {
        return '🚧 Пока нет активных зеркал. Мы обновим список, как только появятся новые точки входа.';
    }

    return mirrors
        .map((mirror, idx) => `${idx + 1}. <b>${mirror.title || `Зеркало #${mirror.id}`}</b>
${mirror.url}`)
        .join('\n\n');
}

const planProcessingUsers = new Set();

function buildPlanMenuText() {
    return `⚔️ <b>Hack VPN</b> — приватный доступ с VLESS + REALITY\n\n${formatPlanHighlights()}\n\n🚀 Мгновенное подключение • Стабильные сервера • Поддержка 24/7`;
}

function isRateLimited(userId) {
    const now = Date.now();
    const entry = rateLimit.get(userId);

    if (!entry || now - entry.windowStart > RATE_LIMIT_WINDOW_MS) {
        rateLimit.set(userId, { count: 1, windowStart: now });
        return false;
    }

    if (entry.count >= RATE_LIMIT_MAX_REQUESTS) {
        return true;
    }

    entry.count += 1;
    return false;
}

async function sendPlanMenu(ctx, mode = 'edit') {
    const text = buildPlanMenuText();
    const options = {
        parse_mode: 'HTML',
        disable_web_page_preview: true,
        ...createPlanKeyboard()
    };

    if (mode === 'edit') {
        return safeEditOrReply(ctx, text, options);
    }
    return ctx.reply(text, options);
}

async function respondInsufficientBalance(ctx, plan) {
    await ctx.reply(
        `❌ Для тарифа «${plan.label}» нужно ${plan.price} ⭐. Пополните баланс и возвращайтесь — конфиг ждёт вас!`,
        createPaymentKeyboard()
    );
}

async function safeEditOrReply(ctx, text, options = {}) {
    const canEdit = Boolean(ctx.callbackQuery?.message?.text);

    if (canEdit) {
        try {
            return await ctx.editMessageText(text, options);
        } catch (error) {
            const description = error?.response?.description || '';
            if (
                description.includes('no text in the message to edit') ||
                description.includes('message is not modified') ||
                description.includes('message to edit not found')
            ) {
                return ctx.reply(text, options);
            }
            throw error;
        }
    }

    return ctx.reply(text, options);
}

async function processPlanPurchase(ctx, planCode) {
    const plan = PLANS[planCode];
    if (!plan) {
        await ctx.answerCbQuery('Тариф недоступен', { show_alert: true });
        return;
    }

    try {
        await ctx.answerCbQuery();
    } catch (e) {}

    const userId = ctx.from.id;
    if (planProcessingUsers.has(userId)) {
        await ctx.reply('⏳ Запрос уже обрабатывается. Подождите пару секунд.');
        return;
    }

    planProcessingUsers.add(userId);
    let balanceDeducted = false;

    try {
        const user = await db.getUser(userId);
        const currentBalance = user.balance || 0;
        if (currentBalance < plan.price) {
            await respondInsufficientBalance(ctx, plan);
            return;
        }

        await db.deductBalance(userId, plan.price, `Покупка тарифа ${plan.label}`);
        balanceDeducted = true;

        if (!marzbanClient.isConfigured()) {
            throw new Error('Marzban API не сконфигурирован');
        }

        const marzbanData = await marzbanClient.provisionUser({
            userId,
            durationDays: plan.durationDays,
            planCode: plan.code
        });

        await db.upsertService(userId, {
            marzban_username: marzbanData.username,
            subscription_url: marzbanData.subscription_url,
            plan_code: plan.code,
            expire_at: marzbanData.expire
        });

        const successText = `✅ <b>${plan.label}</b> активирован!\n\n🔗 Подписка:<code>${marzbanData.subscription_url}</code>\n⏳ Действует до: ${formatExpireDate(marzbanData.expire)}\n\n📲 Импортируйте ссылку в ваш клиент и мгновенно подключайтесь.`;

        await ctx.reply(successText, {
            parse_mode: 'HTML',
            disable_web_page_preview: true,
            ...createStartKeyboard()
        });
    } catch (error) {
        console.error('Error while provisioning plan:', error);
        if (balanceDeducted) {
            await db.updateBalance(userId, plan.price, 'refund', `Возврат за ${plan.label}`);
        }
        const errorMessage = error.message.includes('Marzban')
            ? '⚠️ Панель временно недоступна. Мы уже подключаем резервную ноду.'
            : '❌ Не удалось активировать подписку. Попробуйте ещё раз или напишите поддержке.';
    } finally {
        planProcessingUsers.delete(userId);
    }
}

const bot = new Telegraf(BOT_TOKEN);
const db = new Database();

const userSessions = {};
const supportRequests = {};
const answeredRequests = new Set();
const processingUsers = new Set();

const rateLimit = new Map();

if (!fs.existsSync('backups')) {
    fs.mkdirSync('backups');
}

async function rotateBackups() {
    try {
        const backupName = `bot_backup_${Date.now()}.db`;
        await fsp.copyFile('bot.db', `backups/${backupName}`);
        const files = (await fsp.readdir('backups')).sort();
        while (files.length > 7) {
            await fsp.unlink(`backups/${files.shift()}`);
        }
    } catch (error) {
        console.error('Backup rotation error:', error);
    }
}

rotateBackups();
setInterval(() => rotateBackups().catch((err) => console.error('Backup cron error:', err)), 24 * 60 * 60 * 1000);

bot.start(async (ctx) => {
    try {
        const userId = ctx.from.id;
        if (isRateLimited(userId)) {
            await ctx.reply('⏳ Слишком много запросов. Попробуйте через минуту.');
            return;
        }

        if (processingUsers.has(userId)) {
            await ctx.reply('⏳ Ваш запрос обрабатывается, подождите...');
            return;
        }

        processingUsers.add(userId);

        const username = ctx.from.username || `user_${userId}`;

        await db.ensureUser(userId, username);

        const text = `⚔️ <b>Hack VPN</b> — приватный VPN-сервис с VLESS + REALITY.\n\n📢 Присоединяйтесь к каналу: ${TG_CHANNEL}\n\n⚡ Жми «Топовые тарифы», чтобы получить приватный доступ.`;

        await ctx.reply(text, {
            parse_mode: 'HTML',
            disable_web_page_preview: true,
            ...createStartKeyboard()
        });

        processingUsers.delete(userId);
    } catch (error) {
        console.error('Error in /start:', error);
        await ctx.reply('Произошла ошибка. Попробуйте снова.');
        processingUsers.delete(ctx.from.id);
    }
});

bot.action('balance', async (ctx) => {
    try {
        userSessions[ctx.from.id] = { awaitingAmount: true };
        await safeEditOrReply(
            ctx,
            '💰 Введите количество звёзд для пополнения (минимум 10):',
            Markup.inlineKeyboard([[Markup.button.callback('◀️ Назад', 'back_to_start')]])
        );
    } catch (error) {
        console.error('Error in balance action:', error);
        await ctx.reply('Ошибка при создании счёта');
    }
});

bot.action('get_vpn', async (ctx) => {
    try {
        await sendPlanMenu(ctx);
    } catch (error) {
        console.error('Error in get_vpn action:', error);
    }
});

bot.action('plan_1m', (ctx) => processPlanPurchase(ctx, 'plan_1m'));
bot.action('plan_3m', (ctx) => processPlanPurchase(ctx, 'plan_3m'));
bot.action('plan_6m', (ctx) => processPlanPurchase(ctx, 'plan_6m'));

bot.action('profile', async (ctx) => {
    try {
        const userId = ctx.from.id;
        const user = await db.getUser(userId);
        const fullName = [ctx.from.first_name, ctx.from.last_name].filter(Boolean).join(' ') || 'Не указано';
        const usernameLabel = ctx.from.username ? `@${ctx.from.username}` : 'нет';

        const profileText = `👤 <b>Ваш профиль</b>
🆔 ID: <code>${userId}</code>
📛 Full Name: ${fullName}
🔖 Username: ${usernameLabel}
💰 Баланс: ${user.balance || 0} ⭐

🌐 Нужен резервный вход? Жмите «🌐 Зеркала» — там всегда актуальные ссылки.
🔄 Продлите доступ через «Топовые тарифы» или пополните баланс.`;

        const profileKeyboard = createProfileKeyboard();

        let avatarFileId = null;
        try {
            const photos = await ctx.telegram.getUserProfilePhotos(userId, 0, 1);
            if (photos.total_count > 0 && photos.photos[0]?.length) {
                avatarFileId = photos.photos[0][0].file_id;
            }
        } catch (error) {
            console.error('Error fetching profile photo:', error);
        }

        if (avatarFileId) {
            try {
                await ctx.deleteMessage();
            } catch (e) {}

            await ctx.replyWithPhoto(avatarFileId, {
                caption: profileText,
                parse_mode: 'HTML',
                disable_notification: true,
                ...profileKeyboard
            });
        } else {
            await safeEditOrReply(ctx, profileText, {
                parse_mode: 'HTML',
                disable_web_page_preview: true,
                ...profileKeyboard
            });
        }
    } catch (error) {
        console.error('Error in profile action:', error);
        await ctx.reply('Произошла ошибка при загрузке профиля');
    }
});

bot.action('my_subscriptions', async (ctx) => {
    try {
        const userId = ctx.from.id;
        const service = await db.getService(userId);

        if (!service) {
            await ctx.answerCbQuery('У вас пока нет активных подключений', { show_alert: true });
            return;
        }

        const text = `💠 Ваш доступ
📡 Тариф: ${PLANS[service.plan_code]?.label || service.plan_code}
🔗 Подписка: <code>${service.subscription_url}</code>
⏳ Действует до: ${formatExpireDate(service.expire_at)}

Копируйте ссылку и импортируйте в V2Ray/Shadowrocket.`;

        await safeEditOrReply(ctx, text, {
            parse_mode: 'HTML',
            disable_web_page_preview: true,
            ...createProfileKeyboard()
        });
    } catch (error) {
        console.error('Error in my_subscriptions action:', error);
        await ctx.reply('Не удалось загрузить подключения, попробуйте позднее.');
    }
});

bot.action('mirrors', async (ctx) => {
    try {
        const mirrors = await db.getMirrors(true);
        const mirrorBlock = formatMirrorsText(mirrors);
        const text = `🌐 <b>Актуальные зеркала</b>

${mirrorBlock}

💡 Добавьте ссылки в закладки, чтобы не потерять доступ.`;

        await safeEditOrReply(ctx, text, {
            parse_mode: 'HTML',
            disable_web_page_preview: true,
            ...createMirrorsKeyboard(mirrors)
        });
    } catch (error) {
        console.error('Error in mirrors action:', error);
        await ctx.reply('Не удалось загрузить зеркала, попробуйте позже.');
    }
});

bot.action('support', async (ctx) => {
    try {
        userSessions[ctx.from.id] = { awaitingSupport: true };
        await safeEditOrReply(
            ctx,
            'Напишите ваше сообщение для поддержки:',
            Markup.inlineKeyboard([[Markup.button.callback('◀️ Назад', 'back_to_start')]])
        );
    } catch (error) {
        console.error('Error in support action:', error);
    }
});

bot.on('pre_checkout_query', async (ctx) => {
    try {
        await ctx.answerPreCheckoutQuery(true);
    } catch (error) {
        console.error('Error in pre_checkout_query:', error);
        await ctx.answerPreCheckoutQuery(false, 'Ошибка обработки платежа');
    }
});

bot.on('successful_payment', async (ctx) => {
    try {
        const payload = JSON.parse(ctx.message.successful_payment.invoice_payload || '{}');
        const userId = payload.userId || ctx.from.id;
        const amount = ctx.message.successful_payment.total_amount || payload.amount || 0;

        if (!Number.isFinite(amount) || amount <= 0) {
            await ctx.reply('⚠️ Платёж получен, но сумма не распознана. Напишите поддержке.');
            return;
        }

        await db.updateBalance(userId, amount, 'payment', 'Пополнение баланса');
        await ctx.reply(`✅ Баланс пополнен на ${amount} звёзд!`, createStartKeyboard());
    } catch (error) {
        console.error('Error in successful_payment:', error);
    }
});

bot.on('text', async (ctx) => {
    try {
        const userId = ctx.from.id;
        const text = ctx.message.text;

        if (ADMINS.includes(userId)) {
            if (supportRequests[userId]) {
                const targetUserId = supportRequests[userId];

                if (answeredRequests.has(targetUserId)) {
                    await ctx.reply('❌ Этот вопрос уже закрыт!');
                    delete supportRequests[userId];
                    return;
                }

                answeredRequests.add(targetUserId);
                delete supportRequests[userId];

                try {
                    await bot.telegram.sendMessage(targetUserId, `📨 Ответ от поддержки:\n\n${text}`);
                    await ctx.reply(`✅ Ответ отправлен пользователю ${targetUserId}`);

                    const adminUsername = ctx.from.username || 'admin';

                    for (const adminId of ADMINS) {
                        if (supportRequests.adminMessages?.[adminId]?.[targetUserId]) {
                            try {
                                await bot.telegram.editMessageText(
                                    adminId,
                                    supportRequests.adminMessages[adminId][targetUserId],
                                    null,
                                    `❌ Вопрос решён пользователем @${adminUsername}\n\n👤 Пользователь: @${supportRequests.userInfo?.[targetUserId]?.username || 'без username'}\n🆔 ID: ${targetUserId}\n📅 Дата: ${supportRequests.userInfo?.[targetUserId]?.date || 'неизвестно'}\n\n📝 Сообщение:\n${supportRequests.userInfo?.[targetUserId]?.text || 'неизвестно'}`
                                );
                            } catch (e) {}
                        }
                    }

                    delete supportRequests.userInfo?.[targetUserId];
                } catch (error) {
                    answeredRequests.delete(targetUserId);
                    await ctx.reply(`❌ Не удалось отправить сообщение пользователю ${targetUserId}`);
                    supportRequests[userId] = targetUserId;
                }
                return;
            }

            if (text.startsWith('/admin')) {
                const args = text.trim().split(' ');
                const command = args[1];

                switch (command) {
                    case 'add_vpn': {
                        const apiKey = args[2];
                        if (apiKey) {
                            await db.setApiKey(apiKey);
                            await ctx.reply('✅ API-ключ обновлён');
                        } else {
                            await ctx.reply('❌ Укажите ключ: /admin add_vpn YOUR_API_KEY');
                        }
                        break;
                    }
                    case 'add_mirror': {
                        const url = args[2];
                        const title = args.slice(3).join(' ') || 'Зеркало';
                        if (!url) {
                            await ctx.reply('❌ Укажите URL: /admin add_mirror https://example.com [Название]');
                        } else {
                            await db.addMirror(title, url);
                            await ctx.reply(`✅ Зеркало добавлено:\n${title} — ${url}`);
                        }
                        break;
                    }
                    case 'list_mirrors': {
                        const mirrors = await db.getMirrors(false);
                        if (!mirrors.length) {
                            await ctx.reply('📭 Список зеркал пуст');
                        } else {
                            const listText = mirrors
                                .map((mirror) => `${mirror.id}. ${mirror.title || mirror.url} — ${mirror.is_active ? '✅ активное' : '🚫 выключено'}\n${mirror.url}`)
                                .join('\n\n');
                            await ctx.reply(`🌐 Зеркала:\n\n${listText}`);
                        }
                        break;
                    }
                    case 'remove_mirror': {
                        const removeId = Number(args[2]);
                        if (!removeId) {
                            await ctx.reply('❌ Укажите ID зеркала: /admin remove_mirror 3');
                        } else {
                            await db.removeMirror(removeId);
                            await ctx.reply('🗑 Зеркало удалено');
                        }
                        break;
                    }
                    case 'toggle_mirror': {
                        const targetId = Number(args[2]);
                        const status = args[3];
                        if (!targetId || !['on', 'off'].includes(status)) {
                            await ctx.reply('❌ Используйте: /admin toggle_mirror <id> <on|off>');
                        } else {
                            await db.setMirrorActive(targetId, status === 'on');
                            await ctx.reply(`🔁 Зеркало ${targetId} теперь ${status === 'on' ? 'активно' : 'отключено'}`);
                        }
                        break;
                    }
                    default:
                        await ctx.reply('Команды: add_vpn, add_mirror, list_mirrors, remove_mirror, toggle_mirror');
                }
                return;
            }
        }

        if (userSessions[userId]) {
            if (userSessions[userId].awaitingAmount) {
                const amount = Number(text.trim());
                const MIN_AMOUNT = 10;
                const MAX_AMOUNT = 100000;

                if (!Number.isFinite(amount) || amount % 1 !== 0 || amount < MIN_AMOUNT || amount > MAX_AMOUNT) {
                    await ctx.reply(`❌ Введите целое число от ${MIN_AMOUNT} до ${MAX_AMOUNT}:`, Markup.inlineKeyboard([[Markup.button.callback('◀️ Назад', 'back_to_start')]]));
                    return;
                }

                delete userSessions[userId];

                try {
                    await ctx.replyWithInvoice({
                        title: `Покупка ${amount} звёзд`,
                        description: `Вы покупаете ${amount} звёзды для пополнения баланса.`,
                        payload: JSON.stringify({ userId: userId, amount: amount, type: 'balance' }),
                        start_parameter: 'pay-stars',
                        currency: 'XTR',
                        prices: [{ label: `${amount} звёзд`, amount: amount }],
                        need_name: false,
                        need_phone_number: false,
                        need_email: false,
                        is_flexible: false
                    });
                } catch (error) {
                    console.error('Error creating invoice:', error);
                    await ctx.reply('❌ Ошибка при создании счёта. Попробуйте снова.', createStartKeyboard());
                }
                return;
            }
            
            if (userSessions[userId].awaitingSupport) {
                delete userSessions[userId];
                
                if (answeredRequests.has(userId)) {
                    await ctx.reply('❌ Ваш предыдущий вопрос уже обрабатывается. Пожалуйста, дождитесь ответа.', createStartKeyboard());
                    return;
                }
                
                const userInfo = {
                    username: ctx.from.username || 'без username',
                    userId: userId,
                    date: new Date().toLocaleString(),
                    text: text
                };
                
                supportRequests.userInfo = supportRequests.userInfo || {};
                supportRequests.userInfo[userId] = userInfo;
                
                const messageText = `👤 Пользователь: @${userInfo.username}\n🆔 ID: ${userId}\n📅 Дата: ${userInfo.date}\n\n📝 Сообщение:\n${text}`;
                
                for (const adminId of ADMINS) {
                    try {
                        const sentMessage = await bot.telegram.sendMessage(
                            adminId,
                            messageText,
                            Markup.inlineKeyboard([
                                [Markup.button.callback(`📨 Ответить`, `reply_${userId}`)]
                            ])
                        );
                        
                        supportRequests.adminMessages = supportRequests.adminMessages || {};
                        supportRequests.adminMessages[adminId] = supportRequests.adminMessages[adminId] || {};
                        supportRequests.adminMessages[adminId][userId] = sentMessage.message_id;
                    } catch (e) {
                        console.error('Error sending to admin:', e);
                    }
                }
                
                await ctx.reply('✅ Ваше сообщение отправлено администраторам. Ожидайте ответа.', createStartKeyboard());
                return;
            }
        }
    } catch (error) {
        console.error('Error in text handler:', error);
    }
});

bot.action(/^reply_(\d+)$/, async (ctx) => {
    try {
        const adminId = ctx.from.id;
        if (!ADMINS.includes(adminId)) return;
        
        const targetUserId = parseInt(ctx.match[1]);
        
        if (answeredRequests.has(targetUserId)) {
            await ctx.answerCbQuery('❌ Этот вопрос уже закрыт!', { show_alert: true });
            return;
        }
        
        if (supportRequests[adminId]) {
            await ctx.answerCbQuery('Вы уже отвечаете на другой вопрос!', { show_alert: true });
            return;
        }
        
        supportRequests[adminId] = targetUserId;
        
        await ctx.answerCbQuery();
        await ctx.reply(`✏️ Введите ответ для пользователя ${targetUserId} (@${supportRequests.userInfo?.[targetUserId]?.username || 'без username'}):`);
    } catch (error) {
        console.error('Error in reply action:', error);
    }
});

bot.action('back_to_start', async (ctx) => {
    try {
        delete userSessions[ctx.from.id];
        await safeEditOrReply(ctx, 'Главное меню:', createStartKeyboard());
    } catch (error) {
        console.error('Error in back_to_start:', error);
    }
});

bot.catch((err, ctx) => {
    console.error(`Error for ${ctx.updateType}:`, err);
});

async function startBot() {
    try {
        await bot.launch();
        console.log('🤖 Бот успешно запущен!');
        console.log('Для остановки нажмите Ctrl+C');
    } catch (error) {
        console.error('❌ Ошибка запуска бота:', error);
        console.error('Проверьте токен бота и подключение к интернету');
        process.exit(1);
    }
}

startBot();

process.once('SIGINT', () => {
    console.log('🛑 Остановка бота...');
    bot.stop('SIGINT');
    process.exit(0);
});

process.once('SIGTERM', () => {
    console.log('🛑 Остановка бота...');
    bot.stop('SIGTERM');
    process.exit(0);
});