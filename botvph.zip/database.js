const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');

class Database {
    constructor() {
        this.readyPromise = new Promise((resolve) => {
            this.db = new sqlite3.Database('bot.db', async (err) => {
                if (err) {
                    console.error(err);
                    resolve();
                    return;
                }

                try {
                    await this.initTables();
                    await this.migrateSchema();
                    await Promise.all([
                        this._run('CREATE INDEX IF NOT EXISTS idx_transactions_user ON balance_transactions(user_id)')
                    ]);

                } catch (error) {
                    console.error('Migration error:', error);
                } finally {
                    resolve();
                }
            });
        });
    }

    async ensureDbReady() {
        if (this.readyPromise) {
            await this.readyPromise;
        }
    }

    _all(sql, params = []) {
        return new Promise((resolve, reject) => {
            this.db.all(sql, params, (err, rows) => {
                if (err) reject(err);
                else resolve(rows);
            });
        });
    }

    _get(sql, params = []) {
        return new Promise((resolve, reject) => {
            this.db.get(sql, params, (err, row) => {
                if (err) reject(err);
                else resolve(row);
            });
        });
    }

    _run(sql, params = []) {
        return new Promise((resolve, reject) => {
            this.db.run(sql, params, function(err) {
                if (err) reject(err);
                else resolve({ lastID: this.lastID, changes: this.changes });
            });
        });
    }

    async query(sql, params = []) {
        await this.ensureDbReady();
        return this._all(sql, params);
    }

    async get(sql, params = []) {
        await this.ensureDbReady();
        return this._get(sql, params);
    }

    async run(sql, params = []) {
        await this.ensureDbReady();
        return this._run(sql, params);
    }

    async tableExists(table) {
        const row = await this._get(
            "SELECT name FROM sqlite_master WHERE type='table' AND name = ?",
            [table]
        );
        return Boolean(row);
    }

    async migrateSchema() {
        const mirrorsExists = await this.tableExists('mirrors');
        if (!mirrorsExists) {
            await this._run(`
                CREATE TABLE IF NOT EXISTS mirrors (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT,
                    url TEXT NOT NULL,
                    is_active INTEGER DEFAULT 1,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            `);
        }
    }

    async initTables() {
        await this._run(`
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER UNIQUE,
                username TEXT,
                balance INTEGER DEFAULT 0,
                state TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        await this._run(`
            CREATE TABLE IF NOT EXISTS payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                amount INTEGER,
                status TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        await this._run(`
            CREATE TABLE IF NOT EXISTS config (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        `);

        await this._run(`
            CREATE TABLE IF NOT EXISTS balance_transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                type TEXT,
                amount INTEGER,
                description TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        await this._run(`
            CREATE TABLE IF NOT EXISTS user_services (
                user_id INTEGER PRIMARY KEY,
                marzban_username TEXT,
                subscription_url TEXT,
                plan_code TEXT,
                expire_at INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        await this._run(`
            CREATE TABLE IF NOT EXISTS mirrors (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT,
                url TEXT NOT NULL,
                is_active INTEGER DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);
    }

    async ensureUser(userId, username) {
        try {
            const existing = await this.get('SELECT user_id FROM users WHERE user_id = ?', [userId]);
            
            if (existing) {
                return { user_id: userId };
            }

            await this.run(
                'INSERT INTO users (user_id, username) VALUES (?, ?)',
                [userId, username]
            );

            return { user_id: userId };
        } catch (error) {
            console.error('Error in ensureUser:', error);
            return { user_id: userId };
        }
    }

    async getUser(userId) {
        try {
            const user = await this.get('SELECT * FROM users WHERE user_id = ?', [userId]);
            return user || {};
        } catch (error) {
            console.error('Error in getUser:', error);
            return {};
        }
    }

    async getUserState(userId) {
        try {
            const user = await this.getUser(userId);
            return user.state || null;
        } catch (error) {
            console.error('Error in getUserState:', error);
            return null;
        }
    }

    async updateUserState(userId, state) {
        try {
            await this.run('UPDATE users SET state = ? WHERE user_id = ?', [state, userId]);
        } catch (error) {
            console.error('Error in updateUserState:', error);
        }
    }

    async deductBalance(userId, amount, description = '') {
        try {
            const user = await this.getUser(userId);
            if (user.balance < amount) {
                throw new Error('Недостаточно средств');
            }
            
            await this.run('UPDATE users SET balance = balance - ? WHERE user_id = ?', [amount, userId]);
            await this.logTransaction(userId, 'purchase', -amount, description);
            return true;
        } catch (error) {
            console.error('Error in deductBalance:', error);
            throw error;
        }
    }

    async updateBalance(userId, amount, type = 'manual', description = '') {
        try {
            await this.run('UPDATE users SET balance = balance + ? WHERE user_id = ?', [amount, userId]);
            await this.logTransaction(userId, type, amount, description);
        } catch (error) {
            console.error('Error in updateBalance:', error);
        }
    }

    async logTransaction(userId, type, amount, description = '') {
        try {
            await this.run(
                'INSERT INTO balance_transactions (user_id, type, amount, description) VALUES (?, ?, ?, ?)',
                [userId, type, amount, description]
            );
        } catch (error) {
            console.error('Error in logTransaction:', error);
        }
    }

    async upsertService(userId, data) {
        try {
            const { marzban_username, subscription_url, plan_code, expire_at } = data;
            await this.run(
                `INSERT INTO user_services (user_id, marzban_username, subscription_url, plan_code, expire_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                 ON CONFLICT(user_id) DO UPDATE SET
                    marzban_username = excluded.marzban_username,
                    subscription_url = excluded.subscription_url,
                    plan_code = excluded.plan_code,
                    expire_at = excluded.expire_at,
                    updated_at = CURRENT_TIMESTAMP`,
                [userId, marzban_username, subscription_url, plan_code, expire_at]
            );
        } catch (error) {
            console.error('Error in upsertService:', error);
        }
    }

    async getService(userId) {
        try {
            return await this.get('SELECT * FROM user_services WHERE user_id = ?', [userId]);
        } catch (error) {
            console.error('Error in getService:', error);
            return null;
        }
    }

    async addMirror(title, url) {
        try {
            await this.run(
                'INSERT INTO mirrors (title, url) VALUES (?, ?)',
                [title, url]
            );
        } catch (error) {
            console.error('Error in addMirror:', error);
        }
    }

    async getMirrors(onlyActive = true) {
        try {
            if (onlyActive) {
                return await this.query('SELECT * FROM mirrors WHERE is_active = 1 ORDER BY created_at DESC');
            }
            return await this.query('SELECT * FROM mirrors ORDER BY created_at DESC');
        } catch (error) {
            console.error('Error in getMirrors:', error);
            return [];
        }
    }

    async removeMirror(id) {
        try {
            await this.run('DELETE FROM mirrors WHERE id = ?', [id]);
        } catch (error) {
            console.error('Error in removeMirror:', error);
        }
    }

    async setMirrorActive(id, isActive) {
        try {
            await this.run('UPDATE mirrors SET is_active = ? WHERE id = ?', [isActive ? 1 : 0, id]);
        } catch (error) {
            console.error('Error in setMirrorActive:', error);
        }
    }

    async setApiKey(key) {
        try {
            await this.run('INSERT OR REPLACE INTO config (key, value) VALUES (?, ?)', ['vpn_api_key', key]);
        } catch (error) {
            console.error('Error in setApiKey:', error);
        }
    }

    async getApiKey() {
        try {
            const row = await this.get('SELECT value FROM config WHERE key = ?', ['vpn_api_key']);
            return row ? row.value : null;
        } catch (error) {
            console.error('Error in getApiKey:', error);
            return null;
        }
    }
}

module.exports = Database;